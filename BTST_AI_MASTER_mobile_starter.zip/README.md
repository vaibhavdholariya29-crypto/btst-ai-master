# BTST AI MASTER

Mobile-first starter app for BTST market research.

## Important
This repository currently builds a **DEMO APK**. It does not connect to live market feeds, Angel One SmartAPI, or execute orders. Do not use demo output to make trades.

## Build Android APK
GitHub Actions builds a debug APK when code is pushed to `main` or when the workflow is manually run. Open the repository's **Actions** tab, select **Build Android APK**, then download the `BTST-AI-MASTER-debug-apk` artifact after the run succeeds.

## Live-data integration required
Before live analysis, connect a secure backend using authorized/licensed market-data sources and Angel One SmartAPI. Keep API keys, PIN, TOTP, JWT, and refresh tokens on the backend only; never put secrets in this app or commit them to GitHub. Add historical data, timestamp/coverage checks, and backtesting before displaying calibrated probabilities.

## Safety
Analysis only. No automatic order placement. Options can lose the full premium; BTST positions can gap through stop-loss levels.
