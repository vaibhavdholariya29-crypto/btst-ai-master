import React, {useState} from 'react';
import {createRoot} from 'react-dom/client';
import './style.css';

function App(){
 const [q,setQ]=useState('');
 const [messages,setMessages]=useState([{role:'ai',text:'નમસ્તે! હું BTST AI MASTER છું. NIFTY / BANKNIFTY માટે તમારો પ્રશ્ન પૂછો.'}]);
 const send=()=>{
  if(!q.trim()) return;
  const question=q.trim();
  setMessages(m=>[...m,{role:'user',text:question},{role:'ai',text:'હાલ આ Starter APK DEMO mode માં છે. Live market data જોડાયેલું નથી, તેથી હું સાચો Gap Up/Gap Down અથવા CALL/PUT signal આપી શકતો નથી. Live analysis માટે અધિકૃત Angel One SmartAPI backend અને market-data provider જોડવાના રહેશે. કોઈ trade લેતા પહેલાં પોતે verify કરો.'}]);
  setQ('');
 };
 return <div className="app">
  <header><div className="logo">⚡</div><div><h1>BTST AI MASTER</h1><p>SMART MARKET ASSISTANT</p></div><span className="status">DEMO</span></header>
  <section className="hero"><div className="eyebrow">NEXT-SESSION INTELLIGENCE</div><h2>Trade smarter.<br/><em>Stay protected.</em></h2><p>BTST research assistant for NIFTY, BANKNIFTY & stocks.</p></section>
  <section className="stats"><div><small>MARKET DATA</small><b>Not connected</b></div><div><small>TRADING MODE</small><b>Analysis only</b></div></section>
  <main>{messages.map((m,i)=><div className={'bubble '+m.role} key={i}><small>{m.role==='ai'?'BTST AI':'YOU'}</small><p>{m.text}</p></div>)}</main>
  <div className="prompts">{['કાલે NIFTY gap up કે gap down?','આજના માર્કેટનું analysis કર','BTST માટે risk શું છે?'].map(x=><button key={x} onClick={()=>setQ(x)}>{x}</button>)}</div>
  <div className="composer"><input value={q} onChange={e=>setQ(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="તમારો પ્રશ્ન લખો..."/><button className="send" onClick={send}>➤</button></div>
  <footer>⚠️ Demo only · No live feed · No order execution · Options can expire worthless.</footer>
 </div>
}
createRoot(document.getElementById('root')).render(<App/>);
